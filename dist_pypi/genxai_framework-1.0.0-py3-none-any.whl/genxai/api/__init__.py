"""API utilities for GenXAI (non-Studio)."""

from genxai.api.app import create_app

__all__ = ["create_app"]
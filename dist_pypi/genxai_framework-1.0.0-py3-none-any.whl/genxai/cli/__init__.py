"""GenXAI CLI - Command Line Interface for GenXAI."""

__version__ = "0.1.0"

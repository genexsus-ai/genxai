"""
Auto-generated tool: test-2
Description: testing
Category: custom
Created: 2026-02-03 02:05:46.667101
"""

# Tool code
# Access parameters via 'params' dict
# Example: value = params.get('input_value')

# Your tool logic here
result = {
    "message": "Hello from custom tool!",
    "data": params
}

# Set 'result' variable with your output


"""
Auto-generated tool: test_tool_ui
Description: test
Category: custom
Created: 2026-02-03 02:03:15.074097
"""

# Tool code
result = {"message": "ok"}
